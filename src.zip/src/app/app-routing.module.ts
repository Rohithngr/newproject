import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddtaskComponent } from './components/addtask/addtask.component';
import { TaskeditComponent } from './components/taskedit/taskedit.component';

const routes: Routes = [
  {
    path:'',
    redirectTo: 'addtask',
    pathMatch: 'full'
  },
  {
    path:'addtask',
    component: AddtaskComponent
  },
  {
    path:'editTask/:id',
    component: TaskeditComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
