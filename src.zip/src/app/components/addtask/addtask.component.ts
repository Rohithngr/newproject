import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MyapiService } from 'src/app/shared/myapi.service'; 
@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {
   taskList:any=[];
   showmesg =false;
  constructor(private api:MyapiService) { }
  addtaskForm = new FormGroup({
    addtask : new FormControl(""),
    adddetails : new FormControl(""),
    adddate : new FormControl(""),
  })
  ngOnInit(): void {
    this.api.getTaskdata().subscribe((mydata)=>{
           this.taskList = mydata;
    })
  }

  addtask() {
     this.api.postTask(this.addtaskForm.value).subscribe((data)=>{
          this.showmesg = true;
          this.ngOnInit();   
     })  
  }
  onEdit(row:any) {
      this.addtaskForm.controls['addtask'].setValue(row.addtask)
  }
  onDelete(item:any){
      this.taskList.splice(item-1,1);
     this.api.deleteData(item).subscribe((data)=>{
        this.ngOnInit();
     })
  }

}
