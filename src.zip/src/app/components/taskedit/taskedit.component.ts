import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { MyapiService } from 'src/app/shared/myapi.service';
@Component({
  selector: 'app-taskedit',
  templateUrl: './taskedit.component.html',
  styleUrls: ['./taskedit.component.css']
})
export class TaskeditComponent implements OnInit {
  showmesg = false;
  constructor(private api: MyapiService , private route:ActivatedRoute) { }
  edittaskForm = new FormGroup({
    addtask : new FormControl()
  })
  ngOnInit(): void {     
    this.api.getCurrentData(this.route.snapshot.params.id).subscribe((data:any)=>{
      this.edittaskForm = new FormGroup({
        addtask : new FormControl(data['addtask']),
        adddetails : new FormControl(""),
        adddate : new FormControl(""),
      })
    })
    const updateid = this.route.snapshot.params.id;
    console.log(updateid);
  }
 
  edittask() {
     this.showmesg = true;    
     this.api.updateTaskData(this.route.snapshot.params.id,this.edittaskForm.value)
     .subscribe((updatedata)=>{         
     })

  }
}
